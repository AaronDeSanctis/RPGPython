from CharacterChoiceClass import *
from JapanEnemySelectionClass import *
from SorcererClass import *
from NinjaClass import *
from GuanYuClass import *
from PangDeClass import *
from LuBuClass import *
from GhostSamuraiClass import *
from LightningAngelClass import *
from DragonKnightClass import *

class FeudalJapan(object):
	def __init__(self, player):
		self.player = player
		self.playerAlive = True
		self.enemyAlive = True
		self.playerTurn = True
		self.EnemyTurn = False
		self.Turn = 0
		self.attack = 0
		self.GSOptions = ['Attack', 'Ethereal Blades']
		self.LAOptions = ['Attack', 'Chain Lightning']
		self.DKOptions = ['Attack', 'Implosion']
		
	def ChooseEnemy(self, player):
		JES = JapanEnemySelection()
		enemy = JES.ChooseEnemy(player)
		player = self.BattleEnemy(player, enemy)
		return player
		
	def BattleEnemy(self, player, enemy):
		while (self.enemyAlive == True or self.playerAlive == True):
			try:
				enemy = self.AttackOptions(player, enemy)
				if enemy.currentHP <= 0:
					print (str(player.name) + " has killed the " + (str(enemy.name)) + ".")
					player = enemy.DropEXP(player, enemy)
					self.playerAlive = False
					player = self.ChooseEnemy(player)
					return player
				player = enemy.Attack(player, enemy)	
				if player.currentHP <= 0:
					print (str(player.name) + "has died.")
					if player.lives <= 0:
						print("Game Over")
						player.currentHP = 0
					if player.lives == 1:
						player.lives -= 1
						player.currentHP = player.MaxHP
						pause = input(str(player.name) + " is out of lives!!")
						player = self.ChooseEnemy(player)
						self.playerAlive = False
						return player
			except:
				print ("You fucked up. Bad job.")
				return player
				
						
	def AttackOptions(self, player, enemy):
		DK = DragonKnight()
		GS = GhostSamurai()
		LA = LightningAngel()
		if type(player) == type(GS):
			print (str(self.GSOptions))
			attackGS = input('Choose Your Attack : ')
			if attackGS == "1":
				enemy = player.Attack(player, enemy)
				return enemy
			if attackGS == "2":
				player = player.SpendMP(player)
				if player.currentMP < 0:
					print(str(player.name) + " is out of MP. So " + str(player.name) + " attacks instead.")
					enemy.currentHP = player.Attack(player, enemy)
					return enemy
				else:
					enemy = player.EtherealBlades(player, enemy)	
					return enemy
			else:
				enemy.currentHP = player.Attack(player, enemy)
				return enemy
		if type(player) == type(LA):
			print (str(self.LAOptions))
			attackLA = input('Choose Your Attack : ')
			if attackLA == "1":
				enemy = player.Attack(player, enemy)
				return enemy
			if attackLA == "2":
				player = player.SpendMP(player)
				if player.currentMP < 0:
					print(str(player.name) + " is out of MP. So " + str(player.name) + " attacks instead.")
					enemy = player.Attack(player, enemy)
					return enemy
				else:
					enemy = player.ChainLightning(player, enemy)
					return enemy
			else:
				enemy = player.Attack(player, enemy)
				return enemy
		if type(player) == type(DK):
			print (str(self.DKOptions))
			attackDK = input('Choose Your Attack : ')
			if attackDK == "1":
				enemy = player.Attack(player, enemy)
				return enemy
			if attackDK == "2":
				player = player.SpendMP(player)
				if player.currentMP < 0:
					print(str(player.name) + " is out of MP. So " + str(player.name) + " attacks instead.")
					enemy = player.Attack(player, enemy)
					return enemy
				else:
					enemy = player.Implosion(player, enemy)	
					return enemy		
			else:
				enemy = player.Attack(player, enemy)
				return enemy