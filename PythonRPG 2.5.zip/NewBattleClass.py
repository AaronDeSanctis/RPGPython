class Battle(object):
	def __init__(self, player):