from RatClass import *
from WraithClass import *
from ChimeraClass import *
from SkeletonKingClass import *
from TheMightyZeusClass import *
from EnemyClass import *
from ArenaSelectClass import *

class GreeceEnemySelection(object):
	def __init__(self):
		self.enemyList = ["Rat=1", "Wraith=2", "Chimera=", "Skeleton King=4", "The Mighty Zeus=5"]
	
	def ChooseEnemy(self):
		print (str(self.enemyList))
		print ("Arena Select=0")
		EnemyNum = input("Choose Your Enemy : ")
		if EnemyNum == "1":
			R = Rat()
			print('Rat!!')
			return R
		if EnemyNum == "2":
			W = Wraith()
			print("A Wraith attacks from above!!")
			return W
		if EnemyNum == "3":
			C = Chimera()
			print('A chained chimera is released is heading right for you!!')
			return C
		if EnemyNum == "4":
			S = SkeletonKing()
			print("A great silence looms over you. The Skeleton King never truly dies. Defeat this BOSS!!!!")
			return S
		if EnemyNum == "5":
			T = TheMightyZeus()
			print("Your insane. No one challenges The Mighty Zeus and lives. You have dug your own grave....")
			return T
		if EnemyNum == "0":
			AS = ArenaSelect()
			arena = AS.ChooseArena(player)
			player = arena.ChooseEnemy(player)
			return AS
		else:
			R = Rat()
			print('Rat!!')
			return R
		
		