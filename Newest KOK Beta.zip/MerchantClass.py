

# class Merchant(object):
	# def __init__(self):