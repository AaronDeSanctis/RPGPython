from PlayerClass import *

class GhostSamurai(Player):
	def __init__(self):
		self.currentLevel = 1
		self.DMG = 50
		self.MagDMG = 20
		self.MaxHP = 125
		self.currentHP = self.MaxHP
		self.MaxMP = 35
		self.currentMP = self.MaxMP
		self.SamuraiArmorLevel = 0
		self.ShadowBladeLevel = 0
		self.name = "Ghost Samurai"
		self.MaxEXP = 25
		self.currentEXP = 0
		self.skillcount = 0
	
	def LevelUp(self, player):
		player.currentEXP -= player.MaxEXP
		player.MaxEXP += 25
		player.currentLevel += 1
		player.DMG += 4
		player.MagDMG += 2
		player.MaxHP += 10
		player.currentHP = player.MaxHP
		player.MaxMP += 6
		player.currentMP = player.MaxMP
		player.skillcount += 1
		print (str(player.name) + " has leveled up!!!!")
		if player.skillcount == 5:
			player.skillcount = 0
			skillchoice = input("You have leveled to " + str(player.currentLevel) + ". You may level up a passive ability. Choose 1 for Shadow Blade or 2 for Samurai Armor")
			if skillchoice == 1:
				player = player.LevelHolyLance(player)
				return player
			if skillchoice == 2:
				player = player.LevelDivineAegis(player)
				return player
		else:
			return player
		
	def LevelShadowBlade(self, player):
		player.ShadowBladeLevel += 1
		if player.ShadowBladeLevel == 1:
			player.DMG += 15
			return player
		if player.ShadowBladeLevel == 2:
			player.DMG += 50
			return player
		if player.ShadowBladeLevel == 3:
			player.DMG += 100
			return player
		else:
			player = player.LevelSamuraiArmor(player)
			return player
	
	def LevelSamuraiArmor(self, player):
		player.SamuraiArmorLevel += 1
		if player.SamuraiArmorLevel == 1:
			player.MaxHP += 20
			return player
		if player.SamuraiArmorLevel == 2:
			player.MaxHP += 50
			return player
		if player.SamuraiArmorLevel == 3:
			player.MaxHP += 150
			return player
		else:
			player = player.LevelShadowBlade(player)
			return player
			
	def EtherealBlades(self, player, enemy):
		enemy.currentHP -= player.MagDMG
		E = enemy.currentHP
		print (str(player.name) + " attacks " + str(enemy.name) + " for " + str(player.MagDMG) + " with ethereal blades.")
		print (str(enemy.name) + "'s health is " + str(enemy.currentHP))
		return E
			