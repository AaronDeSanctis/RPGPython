from CharacterChoiceClass import *
from BattleClass import *

class Program(object):
	def __init__(self):
		print ("Knights Of Koth - Arenas by Aaron DeSanctis")
		self.CC = ""
		self.REB = ""
	def StartGame(self):
		CC = CharChoice()
		player = CC.ChooseCharacter()
		while True:
			REB = Battle(player)
			REB.ChooseEnemy(player)

user = Program()
user.StartGame()