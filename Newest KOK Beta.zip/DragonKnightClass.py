from PlayerClass import *

class DragonKnight(Player):
	def __init__(self):
		self.currentLevel = 1
		self.DMG = 60
		self.MagDMG = 10
		self.MaxHP = 150
		self.currentHP = self.MaxHP
		self.MaxMP = 10
		self.currentMP = self.MaxMP
		self.FrostArmorLevel = 0
		self.FlamingSwordLevel = 0
		self.name = "Dragon Knight"
		self.MaxEXP = 25
		self.currentEXP = 0
		self.skillcount = 0
		
	def LevelUp(self, player):
		player.currentEXP -= player.MaxEXP
		player.MaxEXP += 25
		player.currentLevel += 1
		player.DMG += 5
		player.MagDMG += 1
		player.MaxHP += 15
		player.currentHP = player.MaxHP
		player.MaxMP += 1
		player.currentMP = player.MaxMP
		player.skillcount += 1
		print (str(player.name) + " has leveled up!!!!")
		if player.skillcount == 5:
			player.skillcount = 0
			skillchoice = input("You have leveled to " + str(player.currentLevel) + ". You may level up a passive ability. Choose 1 for Frost Armor or 2 for Flaming Sword")
			if skillchoice == 1:
				player = player.LevelFrostArmor(player)
				return player
			if skillchoice == 2:
				player = player.LevelFlamingSword(player)
				return player
		else:
			return player
	
	def LevelFrostArmor(self, player):
		player.FrostArmorLevel += 1
		if player.FrostArmorLevel == 1:
			player.MaxHP += 30
			return player
		if player.FrostArmorLevel == 2:
			player.MaxHP += 75
			return player
		if player.FrostArmorLevel == 3:
			player.MaxHP += 200
			return player
		else:
			player.LevelFlamingSword(player)
			return player
			
	def LevelFlamingSword(self, player):
		player.FlamingSwordLevel += 1
		if player.FlamingSwordLevel == 1:
			player.DMG += 10
			return player
		if player.FlamingSwordLevel == 2:
			player.DMG += 25
			return player
		if player.FlamingSwordLevel == 3:
			player.DMG += 100
			return player
		else:
			player.LevelFrostArmor(player)
			return player
			
	def Implosion(self, player, enemy):
		enemy.currentHP -= player.MagDMG
		E = enemy.currentHP
		print (str(player.name) + " attacks " + str(enemy.name) + " for " + str(player.MagDMG) + " with an implosion.")
		print (str(enemy.name) + "'s health is " + str(enemy.currentHP))
		return E
		