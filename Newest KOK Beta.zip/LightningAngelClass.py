from PlayerClass import *

class LightningAngel(Player):
	def __init__(self):
		self.currentLevel = 1
		self.DMG = 20
		self.MagDMG = 50
		self.MaxHP = 110
		self.currentHP = self.MaxHP
		self.MaxMP = 50
		self.currentMP = self.MaxMP
		self.DivineAegisLevel = 0
		self.HolyLanceLevel = 0
		self.name = "Lightning Angel"
		self.MaxEXP = 25
		self.currentEXP = 0
		self.skillcount = 0
	
	def LevelUp(self, player):
		player.currentEXP -= player.MaxEXP
		player.MaxEXP += 25
		player.currentLevel += 1
		player.DMG += 2
		player.MagDMG += 4
		player.MaxHP += 8
		player.currentHP = player.MaxHP
		player.MaxMP += 8
		player.currentMP = player.MaxMP
		player.skillcount += 1
		print (str(player.name) + " has leveled up!!!!")
		if player.skillcount == 5:
			player.skillcount = 0
			skillchoice = input("You have leveled to " + str(player.currentLevel) + ". You may level up a passive ability. Choose 1 for Holy Lance or 2 for Divine Aegis")
			if skillchoice == 1:
				player = player.LevelHolyLance(player)
				return player
			if skillchoice == 2:
				player = player.LevelDivineAegis(player)
				return player
		else:
			return player

	def LevelDivineAegis(self, player):
		player.DivineAegisLevel += 1
		if player.DivineAegisLevel == 1:
			player.MaxHP += 30
			return player
		if player.DivineAegisLevel == 2:
			player.MaxHP += 75
			return player
		if player.DivineAegisLevel == 3:
			player.MaxHP += 150
			return player
		else:
			print ("You have maxed out Divine Aegis.")
			player = player.LevelHolyLance(player)
			return player
			
	def LevelHolyLance(self, player):
		player.HolyLanceLevel += 1
		if player.HolyLanceLevel == 1:
			player.DMG += 40
			return player
		if player.HolyLanceLevel == 2:
			player.DMG += 100
			return player
		if player.HolyLanceLevel == 3:
			player.DMG += 200
			return player
		else:
			print ("You have maxed out Holy Lance")
			player = player.LevelDivineAegis(player)
			return player
		
	def LightningBolt(self, player, enemy):
		enemy.currentHP -= player.MagDMG
		E = enemy.currentHP
		print (str(player.name) + " attacks " + str(enemy.name) + " for " + str(player.MagDMG) + " with chain lightning.")
		print (str(enemy.name) + "'s health is " + str(enemy.currentHP))
		return E	
	
		