from CharacterChoiceClass import *
from EnemySelection import *
from RatClass import *
from WraithClass import *
from ChimeraClass import *
from SkeletonKingClass import *
from TheMightyZeusClass import *
from GhostSamuraiClass import *
from LightningAngelClass import *
from DragonKnightClass import *

class Battle(object):
	def __init__(self, player):
		self.player = player
		self.playerAlive = True
		self.enemyAlive = True
		self.playerTurn = True
		self.EnemyTurn = False
		self.Turn = 0
		self.attack = 0
		self.GSOptions = ['Attack', 'Ethereal Blades']
		self.LAOptions = ['Attack', 'Chain Lightning']
		self.DKOptions = ['Attack', 'Implosion']
	def ChooseEnemy(self, player):
		ES = EnemySelection()
		enemy = ES.ChooseEnemy()
		self.BattleEnemy(player, enemy)
	def BattleEnemy(self, player, enemy):
		while (self.enemyAlive == True or self.playerAlive == True):
			try:
				enemy.currentHP = self.AttackOptions(player, enemy)
				if player.currentHP <= 0:
					print (str(player.name) + "has died.")
					self.playerAlive = False
					return player
				if enemy.currentHP <= 0:
					print (str(player.name) + " has killed the " + (str(enemy.name)) + ".")
					player = enemy.DropEXP(player, enemy)
					self.enemyAlive = False
					return player
				player.currentHP = enemy.Attack(player, enemy)	
				if player.currentHP <= 0:
					print (str(player.name) + "has died.")
					self.playerAlive = False
					return player
				if enemy.currentHP <= 0:
					print (str(player.name) + " has killed the " + (str(enemy.name)) + ".")
					player = enemy.DropEXP(player, enemy)
					self.enemyAlive = False
					return player
			except:
				print ("You fucked up. Bad job.")
				return player
				
						
	def AttackOptions(self, player, enemy):
		DK = DragonKnight()
		GS = GhostSamurai()
		LA = LightningAngel()
		if type(player) == type(GS):
			print (str(self.GSOptions))
			attackGS = input('Choose Your Attack : ')
			if attackGS == "1":
				enemy.currentHP = player.Attack(player, enemy)
				return enemy.currentHP
			if attackGS == "2":
				enemy.currentHP = player.EtherealBlades(player, enemy)	
				return enemy.currentHP
			else:
				enemy.currentHP = player.Attack(player, enemy)
				return enemy.currentHP
		if type(player) == type(LA):
			print (str(self.LAOptions))
			attackLA = input('Choose Your Attack : ')
			if attackLA == "1":
				enemy.currentHP = player.Attack(player, enemy)
				return enemy.currentHP
			if attackLA == "2":
				player = player.SpendMP(player)
				if player.currentMP < 0:
					print(str(player.name) + " is out of MP. So " + str(player.name) + " attacks instead.")
					enemy.currentHP = player.Attack(player, enemy)
					return enemy.currentHP
				else:
					enemy.currentHP = player.ChainLightning(player, enemy)
					return enemy.currentHP
			else:
				enemy.currentHP = player.Attack(player, enemy)
				return enemy.currentHP
		if type(player) == type(DK):
			print (str(self.DKOptions))
			attackDK = input('Choose Your Attack : ')
			if attackDK == "1":
				enemy.currentHP = player.Attack(player, enemy)
				return enemy.currentHP
			if attackDK == "2":
				player = player.SpendMP(player)
				if player.currentMP < 0:
					print(str(player.name) + " is out of MP. So " + str(player.name) + " attacks instead.")
					enemy.currentHP = player.Attack(player, enemy)
					return enemy.currentHP
				else:
					enemy.currentHP = player.Implosion(player, enemy)	
					return enemy.currentHP		
			else:
				enemy.currentHP = player.Attack(player, enemy)
				return enemy.currentHP